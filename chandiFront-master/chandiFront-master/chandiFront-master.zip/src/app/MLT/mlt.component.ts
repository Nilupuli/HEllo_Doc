import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mlt',
  templateUrl: './mlt.component.html',
  styleUrls: ['./mlt.component.css']
})
export class MltComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
