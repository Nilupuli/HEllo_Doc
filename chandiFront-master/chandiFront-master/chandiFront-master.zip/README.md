# Tritech 

## git clone the repository

### run following codes in terminal

npm install <br>
npm start

### project will run on localhost:4200
