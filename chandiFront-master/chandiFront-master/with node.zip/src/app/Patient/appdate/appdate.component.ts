import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appdate',
  templateUrl: './appdate.component.html',
  styleUrls: ['./appdate.component.css']
})
export class AppdateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
